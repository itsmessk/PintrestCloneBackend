package com.infy.pinterest;

import com.infy.pinterest.dto.BoardCreationDTO;
import com.infy.pinterest.dto.BoardResponseDTO;
import com.infy.pinterest.dto.BoardUpdateDTO;
import com.infy.pinterest.entity.Board;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.exception.BoardNotFoundException;
import com.infy.pinterest.exception.ResourceNotFoundException;
import com.infy.pinterest.repository.BoardRepository;
import com.infy.pinterest.repository.UserRepository;
import com.infy.pinterest.service.BoardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class BoardServiceTest {

    @Mock
    private BoardRepository boardRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private BoardService boardService;

    private User user;
    private Board board;
    private BoardCreationDTO creationDTO;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId("user-123");
        user.setUsername("johndoe");
        user.setEmail("john@example.com");

        board = new Board();
        board.setBoardId("board-123");
        board.setUserId("user-123");
        board.setName("Travel Inspiration");
        board.setDescription("Places I want to visit");
        board.setVisibility(Board.Visibility.PUBLIC);
        board.setPinCount(0);

        creationDTO = new BoardCreationDTO();
        creationDTO.setName("Travel Inspiration");
        creationDTO.setDescription("Places I want to visit");
        creationDTO.setVisibility("PUBLIC");
    }
    @Test
    void testCreateBoard_Success() {
        // Arrange
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        when(boardRepository.save(any(Board.class))).thenReturn(board);
        when(modelMapper.map(any(), any())).thenReturn(new BoardResponseDTO());

        // Act
        BoardResponseDTO result = boardService.createBoard("user-123", creationDTO);

        // Assert
        assertNotNull(result);
        verify(boardRepository, times(1)).save(any(Board.class));
    }

    @Test
    void testCreateBoard_UserNotFound() {
        // Arrange
        when(userRepository.findById(anyString())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            boardService.createBoard("invalid-user", creationDTO);
        });
    }

    @Test
    void testUpdateBoard_Success() {
        // Arrange
        BoardUpdateDTO updateDTO = new BoardUpdateDTO();
        updateDTO.setName("Updated Board Name");

        when(boardRepository.findByBoardIdAndUserId(anyString(),
                anyString())).thenReturn(Optional.of(board));
        when(boardRepository.save(any(Board.class))).thenReturn(board);
        when(modelMapper.map(any(), any())).thenReturn(new BoardResponseDTO());

        // Act
        BoardResponseDTO result = boardService.updateBoard("user-123", "board-123", updateDTO);

        // Assert
        assertNotNull(result);
        verify(boardRepository, times(1)).save(any(Board.class));
    }

    @Test
    void testDeleteBoard_Success() {
        // Arrange
        when(boardRepository.findByBoardIdAndUserId(anyString(),anyString())).thenReturn(Optional.of(board));
        doNothing().when(boardRepository).delete(any(Board.class));

        // Act
        boardService.deleteBoard("user-123", "board-123");

        // Assert
        verify(boardRepository, times(1)).delete(any(Board.class));
    }

    @Test
    void testGetBoardById_Success() {
        // Arrange
        when(boardRepository.findById(anyString())).thenReturn(Optional.of(board));
        when(modelMapper.map(any(), any())).thenReturn(new BoardResponseDTO());

        // Act
        BoardResponseDTO result = boardService.getBoardById("board-123");

        // Assert
        assertNotNull(result);
    }

    @Test
    void testGetBoardById_NotFound() {
        // Arrange
        when(boardRepository.findById(anyString())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(BoardNotFoundException.class, () -> {
            boardService.getBoardById("invalid-board");
        });
    }
}
