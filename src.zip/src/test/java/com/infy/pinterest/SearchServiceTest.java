package com.infy.pinterest;
import com.infy.pinterest.dto.PinSearchResultDTO;
import com.infy.pinterest.dto.SearchRequestDTO;
import com.infy.pinterest.dto.SearchResultDTO;
import com.infy.pinterest.entity.Pin;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.repository.BoardRepository;
import com.infy.pinterest.repository.PinRepository;
import com.infy.pinterest.repository.UserRepository;
import com.infy.pinterest.service.SearchService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)

public class SearchServiceTest {

    @Mock
    private PinRepository pinRepository;

    @Mock
    private BoardRepository boardRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private SearchService searchService;

    private Pin pin;
    private User user;
    private SearchRequestDTO searchRequest;
    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId("user-123");
        user.setUsername("johndoe");

        pin = new Pin();
        pin.setPinId("pin-123");
        pin.setUserId("user-123");
        pin.setTitle("Beautiful Sunset");
        pin.setDescription("Amazing view");
        pin.setImageUrl("/uploads/image.jpg");
        pin.setVisibility(Pin.Visibility.PUBLIC);
        pin.setIsDraft(false);
        pin.setSaveCount(100);
        pin.setLikeCount(50);

        searchRequest = new SearchRequestDTO();
        searchRequest.setQuery("sunset");
        searchRequest.setPage(0);
        searchRequest.setSize(20);
        searchRequest.setSortBy("relevance");
    }

    @Test
    void testSearchPins_Success() {
        // Arrange
        List<Pin> pins = Arrays.asList(pin);
        Page<Pin> pinPage = new PageImpl<>(pins);

        when(pinRepository.searchPins(anyString(), any(Pageable.class))).thenReturn(pinPage);
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        when(pinRepository.findTitleSuggestions(anyString(), any(Pageable.class)))
                .thenReturn(Arrays.asList("sunset beach", "sunset colors"));

        // Act
        SearchResultDTO<PinSearchResultDTO> result = searchService.searchPins(searchRequest);

        // Assert
        assertNotNull(result);
        assertEquals("sunset", result.getQuery());
        assertFalse(result.getResults().isEmpty());
        assertNotNull(result.getSuggestions());
        verify(pinRepository, times(1)).searchPins(anyString(), any(Pageable.class));
    }

    @Test
    void testSearchPins_WithCategory() {
        // Arrange
        searchRequest.setCategory("travel");List<Pin> pins = Arrays.asList(pin);
        Page<Pin> pinPage = new PageImpl<>(pins);

        when(pinRepository.searchPinsByCategory(anyString(), anyString(), any(Pageable.class)))
                .thenReturn(pinPage);
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));

        // Act
        SearchResultDTO<PinSearchResultDTO> result = searchService.searchPins(searchRequest);

        // Assert
        assertNotNull(result);
        verify(pinRepository, times(1)).searchPinsByCategory(anyString(), anyString(),
                any(Pageable.class));
    }

    @Test
    void testGetSearchSuggestions_Success() {
        // Arrange
        List<String> suggestions = Arrays.asList("sunset beach", "sunset photography", "sunset colors");
                when(pinRepository.findTitleSuggestions(anyString(), any(Pageable.class)))
                        .thenReturn(suggestions);
        // Act
        List<String> result = searchService.getSearchSuggestions("sun");
        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(pinRepository, times(1)).findTitleSuggestions(anyString(),any(Pageable.class));
    }

    @Test
    void testGetSearchSuggestions_EmptyKeyword() {
        // Act
        List<String> result = searchService.getSearchSuggestions("");

        // Assert
        assertTrue(result.isEmpty());
        verify(pinRepository, never()).findTitleSuggestions(anyString(), any(Pageable.class));
    }
    @Test
    void testGetPopularPins_Success() {
        // Arrange
        List<Pin> pins = Arrays.asList(pin);
        Page<Pin> pinPage = new PageImpl<>(pins);
        when(pinRepository.findPopularPins(any(Pageable.class))).thenReturn(pinPage);
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        // Act
        var result = searchService.getPopularPins(0, 20);
        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertFalse(result.getData().isEmpty());
        assertEquals(1,result.getData().size());

        verify(pinRepository,times(1)).findPopularPins(any(Pageable.class));
    }
}
