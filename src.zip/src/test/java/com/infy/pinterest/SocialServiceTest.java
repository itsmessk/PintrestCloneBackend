package com.infy.pinterest;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import com.infy.pinterest.dto.InvitationResponseActionDTO;
import com.infy.pinterest.dto.InvitationSendDTO;
import com.infy.pinterest.dto.UserReportDTO;
import com.infy.pinterest.entity.Board;
import com.infy.pinterest.entity.Follow;
import com.infy.pinterest.entity.Invitation;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.exception.AlreadyFollowingException;
import com.infy.pinterest.exception.NotFollowingException;
import com.infy.pinterest.exception.ResourceNotFoundException;
import com.infy.pinterest.exception.SelfFollowException;
import com.infy.pinterest.repository.*;
import com.infy.pinterest.service.SocialService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
@SpringBootTest
@AutoConfigureMockMvc
class SocialServiceTest {

    @Mock
    private FollowRepository followRepository;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Mock
    private UserRepository userRepository;

    @Mock
    private InvitationRepository invitationRepository;
    @Mock
    private BoardCollaboratorRepository collaboratorRepository;

    @Mock
    private BlockedUserRepository blockedUserRepository;

    @Mock
    private UserReportRepository userReportRepository;

    @InjectMocks
    private SocialService socialService;

    private User user1;
    private User user2;
    private Follow follow;
    private Board board;
    private Invitation invitation;

    @BeforeEach
    void setUp() {
        user1 = new User();
        user1.setUserId("user-1");
        user1.setUsername("john");
        user1.setFullName("John Doe");
        user1.setProfilePictureUrl("/uploads/john.jpg");
        user1.setBio("Travel enthusiast");

        user2 = new User();
        user2.setUserId("user-2");
        user2.setUsername("jane");
        user2.setFullName("Jane Doe");
        user2.setProfilePictureUrl("/uploads/jane.jpg");
        user2.setBio("Food blogger");

        follow = new Follow();
        follow.setFollowId("follow-1");
        follow.setFollowerId("user-1");
        follow.setFollowingId("user-2");
        follow.setFollowedAt(LocalDateTime.now());

        board = new Board();
        board.setBoardId("board-1");
        board.setUserId("user-1");
        board.setName("Test Board");
        board.setIsCollaborative(false);

        invitation = new Invitation();
        invitation.setInvitationId("invite-1");
        invitation.setBoardId("board-1"); invitation.setFromUserId("user-1");
        invitation.setToUserId("user-2");
        invitation.setPermission(Invitation.Permission.EDIT);
        invitation.setStatus(Invitation.Status.PENDING);
        invitation.setMessage("Join my board!");
    }

    // ============================================================
    // FOLLOW USER TESTS
    // ============================================================

    @Test
    void testFollowUser_Success() {
        // Arrange
        when(userRepository.findById("user-1")).thenReturn(Optional.of(user1));
        when(userRepository.findById("user-2")).thenReturn(Optional.of(user2));
        when(followRepository.existsByFollowerIdAndFollowingId("user-1", "user-2")).thenReturn(false);
                when(followRepository.save(any(Follow.class))).thenReturn(follow);

        // Act
        socialService.followUser("user-1", "user-2");

        // Assert
        verify(followRepository, times(1)).save(any(Follow.class));
        verify(userRepository, times(1)).findById("user-1");
        verify(userRepository, times(1)).findById("user-2");
        verify(followRepository, times(1)).existsByFollowerIdAndFollowingId("user-1", "user-2");
    }

    @Test
    void testFollowUser_SelfFollow_ThrowsException() {
        // Act & Assert
        SelfFollowException exception = assertThrows(SelfFollowException.class, () -> {
            socialService.followUser("user-1", "user-1");
        });

        assertEquals("You cannot follow yourself", exception.getMessage());
        verify(followRepository, never()).save(any());
        verify(userRepository, never()).findById(anyString());
    }

    @Test
    void testFollowUser_AlreadyFollowing_ThrowsException() {
        // Arrange
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user1));
        when(followRepository.existsByFollowerIdAndFollowingId("user-1", "user-2")).thenReturn(true);

                        // Act & Assert
                        AlreadyFollowingException exception = assertThrows(AlreadyFollowingException.class, () -> {
                        socialService.followUser("user-1", "user-2");
        });

        assertEquals("You are already following this user", exception.getMessage());
        verify(followRepository, never()).save(any());
    }

    @Test
    void testFollowUser_FollowerNotFound_ThrowsException() {
        // Arrange
        when(userRepository.findById("user-1")).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
                socialService.followUser("user-1", "user-2");
        });

        assertEquals("Follower user not found", exception.getMessage());
        verify(followRepository, never()).save(any());
    }

    @Test
    void testFollowUser_FollowingNotFound_ThrowsException() {
        // Arrange
        when(userRepository.findById("user-1")).thenReturn(Optional.of(user1));
        when(userRepository.findById("user-2")).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
                socialService.followUser("user-1", "user-2");
        });

        assertEquals("Following user not found", exception.getMessage());
        verify(followRepository, never()).save(any());
    }

    // ============================================================
    // UNFOLLOW USER TESTS
    // ============================================================

    @Test
    void testUnfollowUser_Success() {
        // Arrange
        when(followRepository.existsByFollowerIdAndFollowingId("user-1", "user-2")).thenReturn(true);
                doNothing().when(followRepository).deleteByFollowerIdAndFollowingId("user-1", "user-2"); // Act
        socialService.unfollowUser("user-1", "user-2");

        // Assert
        verify(followRepository, times(1)).deleteByFollowerIdAndFollowingId("user-1", "user-2");
        verify(followRepository, times(1)).existsByFollowerIdAndFollowingId("user-1", "user-2");
    }

    @Test
    void testUnfollowUser_NotFollowing_ThrowsException() {
        // Arrange
        when(followRepository.existsByFollowerIdAndFollowingId("user-1", "user-2")).thenReturn(false);

                // Act & Assert
                NotFollowingException exception = assertThrows(NotFollowingException.class, () -> {
                    socialService.unfollowUser("user-1", "user-2");
                });

        assertEquals("You are not following this user", exception.getMessage());
        verify(followRepository, never()).deleteByFollowerIdAndFollowingId(anyString(),
                anyString());
    }

    // ============================================================
    // GET FOLLOWERS TESTS
    // ============================================================

    @Test
    void testGetFollowers_Success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/social/followers/user-1")
                        .header("X-User-Id", "user-1")
                        .param("page", "0")
                        .param("size", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.pagination").exists())
                .andExpect(jsonPath("$.data.data").isArray());
    }

    @Test
    void testGetFollowing_Success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/social/following/user-1")
                        .header("X-User-Id", "user-1")
                        .param("page", "0")
                        .param("size", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.pagination").exists()); }

    @Test
    void testGetFollowStats_Success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/social/stats/user-1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.followers").exists())
                .andExpect(jsonPath("$.data.following").exists());
    }

    @Test
    void testSendInvitation_Success() throws Exception {
        InvitationSendDTO inviteDTO = new InvitationSendDTO();
        inviteDTO.setRecipientUsername("testuser2");
        inviteDTO.setBoardId("board-1");
        inviteDTO.setMessage("Join my board!");
        inviteDTO.setPermission("EDIT");

        mockMvc.perform(post("/api/v1/social/invitations/send")
                        .header("X-User-Id", "user-1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inviteDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.invitationId").exists());
    }

    @Test
    void testSendInvitation_ValidationError() throws Exception {
        InvitationSendDTO inviteDTO = new InvitationSendDTO();
        // Missing required fields

        mockMvc.perform(post("/api/v1/social/invitations/send")
                        .header("X-User-Id", "user-1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inviteDTO)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testGetInvitations_Success() throws Exception {
        mockMvc.perform(get("/api/v1/social/invitations")
                        .header("X-User-Id", "user-1")
                        .param("page", "0")
                        .param("size", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.data").isArray());
    } @Test
    void testGetInvitations_FilterByStatus() throws Exception {
        mockMvc.perform(get("/api/v1/social/invitations")
                        .header("X-User-Id", "user-1")
                        .param("status", "pending")
                        .param("page", "0")
                        .param("size", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"));
    }

    @Test
    void testRespondToInvitation_Accept() throws Exception {
        InvitationResponseActionDTO actionDTO = new InvitationResponseActionDTO();
        actionDTO.setAction("accept");

        mockMvc.perform(put("/api/v1/social/invitations/invite-1")
                        .header("X-User-Id", "user-2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(actionDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Invitation accepted successfully"));
    }

    @Test
    void testRespondToInvitation_Decline() throws Exception {
        InvitationResponseActionDTO actionDTO = new InvitationResponseActionDTO();
        actionDTO.setAction("decline");

        mockMvc.perform(put("/api/v1/social/invitations/invite-1")
                        .header("X-User-Id", "user-2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(actionDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Invitation declined successfully"));
    }

    @Test
    void testRespondToInvitation_InvalidAction() throws Exception {
        InvitationResponseActionDTO actionDTO = new InvitationResponseActionDTO();
        actionDTO.setAction("invalid");

        mockMvc.perform(put("/api/v1/social/invitations/invite-1")
                        .header("X-User-Id", "user-2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(actionDTO)))
                .andExpect(status().isBadRequest());
    } @Test
    void testBlockUser_Success() throws Exception {
        mockMvc.perform(post("/api/v1/social/block/user-2")
                        .header("X-User-Id", "user-1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.message").value("User blocked successfully"));
    }

    @Test
    void testUnblockUser_Success() throws Exception {
        mockMvc.perform(delete("/api/v1/social/unblock/user-2")
                        .header("X-User-Id", "user-1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("User unblocked successfully"));
    }

    @Test
    void testReportUser_Success() throws Exception {
        UserReportDTO reportDTO = new UserReportDTO();
        reportDTO.setReason("spam");
        reportDTO.setDescription("User is posting spam content");

        mockMvc.perform(post("/api/v1/social/report/user-2")
                        .header("X-User-Id", "user-1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(reportDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Report submitted successfully"));
    }

    @Test
    void testIsFollowing_Success() throws Exception {
        mockMvc.perform(get("/api/v1/social/is-following/user-2")
                        .header("X-User-Id", "user-1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data").isBoolean());
    }

    @Test
    void testFollowUser_MissingHeader() throws Exception {
        mockMvc.perform(post("/api/v1/social/follow/user-2"))
                .andExpect(status().isBadRequest());
    }
}
