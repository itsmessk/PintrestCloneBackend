package com.infy.pinterest;

import com.infy.pinterest.dto.LoginResponseDTO;
import com.infy.pinterest.dto.UserLoginDTO;
import com.infy.pinterest.dto.UserRegistrationDTO;
import com.infy.pinterest.dto.UserResponseDTO;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.exception.InvalidCredentialsException;
import com.infy.pinterest.exception.PasswordMismatchException;
import com.infy.pinterest.exception.ResourceNotFoundException;
import com.infy.pinterest.exception.UserAlreadyExistsException;
import com.infy.pinterest.repository.UserRepository;
import com.infy.pinterest.service.UserService;
import com.infy.pinterest.utility.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;

import org.mockito.InjectMocks; 
import org.mockito.Mock; 
import org.mockito.junit.jupiter.MockitoExtension; 
import org.modelmapper.ModelMapper; 
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; 
import java.util.Optional; 
import static org.junit.jupiter.api.Assertions.*; 
import static org.mockito.ArgumentMatchers.any; 
import static org.mockito.ArgumentMatchers.anyString; 
import static org.mockito.Mockito.*; 
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class UserServiceTest { 
     
    @Mock 
    private UserRepository userRepository;
     
    @Mock 
    private ModelMapper modelMapper; 
     
    @Mock 
    private JwtUtil jwtUtil;
     
    @InjectMocks 
    private UserService userService;
     
    private UserRegistrationDTO registrationDTO;
    private User user;
    private BCryptPasswordEncoder passwordEncoder;

    @BeforeEach
    void setUp() {
        passwordEncoder = new BCryptPasswordEncoder();
         
        registrationDTO = new UserRegistrationDTO(); 
        registrationDTO.setUsername("johndoe"); 
        registrationDTO.setEmail("john@example.com"); 
        registrationDTO.setPassword("SecurePass@123"); 
        registrationDTO.setConfirmPassword("SecurePass@123"); 
         
        user = new User(); 
        user.setUserId("user-123"); 
        user.setUsername("johndoe"); 
        user.setEmail("john@example.com"); 
        user.setPasswordHash(passwordEncoder.encode("SecurePass@123")); 
        user.setAccountType(User.AccountType.personal); 
        user.setFailedLoginAttempts(0); 
    }
    @Test
    void testRegisterUser_Success() { 
        // Arrange 
        when(userRepository.existsByEmail(anyString())).thenReturn(false); 
        when(userRepository.existsByUsername(anyString())).thenReturn(false); 
        when(userRepository.save(any(User.class))).thenReturn(user); 
        when(modelMapper.map(any(), any())).thenReturn(new UserResponseDTO());
         
        // Act 
        UserResponseDTO result = userService.registerUser(registrationDTO); 
         
        // Assert 
        assertNotNull(result); 
        verify(userRepository, times(1)).save(any(User.class)); 
    } 
     
    @Test 
    void testRegisterUser_EmailExists() { 
        // Arrange 
        when(userRepository.existsByEmail(anyString())).thenReturn(true); 
         
        // Act & Assert 
        assertThrows(UserAlreadyExistsException.class, () -> {
            userService.registerUser(registrationDTO); 
        }); 
    } 
     
    @Test 
    void testRegisterUser_PasswordMismatch() { 
        // Arrange 
        registrationDTO.setConfirmPassword("DifferentPassword"); 
         
        // Act & Assert 
        assertThrows(PasswordMismatchException.class, () -> {
            userService.registerUser(registrationDTO); 
        }); 
    } 
     
    @Test 
    void testLoginUser_Success() { 
        // Arrange 
        UserLoginDTO loginDTO = new UserLoginDTO();
        loginDTO.setEmail("john@example.com"); 
        loginDTO.setPassword("SecurePass@123"); 
         
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(user)); 
        when(jwtUtil.generateToken(anyString(), anyString(), anyString())).thenReturn("mock-jwt-token"); // Act
        LoginResponseDTO result = userService.loginUser(loginDTO);
         
        // Assert 
        assertNotNull(result); 
        assertEquals("mock-jwt-token", result.getToken()); 
    } 
     
    @Test 
    void testLoginUser_InvalidCredentials() { 
        // Arrange 
        UserLoginDTO loginDTO = new UserLoginDTO(); 
        loginDTO.setEmail("john@example.com"); 
        loginDTO.setPassword("WrongPassword"); 
         
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(user)); 
         
        // Act & Assert 
        assertThrows(InvalidCredentialsException.class, () -> {
            userService.loginUser(loginDTO); 
        }); 
    } 
     
    @Test 
    void testGetUserById_Success() { 
        // Arrange 
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user)); 
        when(modelMapper.map(any(), any())).thenReturn(new UserResponseDTO()); 
         
        // Act 
        UserResponseDTO result = userService.getUserById("user-123"); 
         
        // Assert 
        assertNotNull(result); 
    } 
     
    @Test 
    void testGetUserById_NotFound() { 
        // Arrange 
        when(userRepository.findById(anyString())).thenReturn(Optional.empty()); 
         
        // Act & Assert 
        assertThrows(ResourceNotFoundException.class, () -> {
            userService.getUserById("invalid-id"); 
        }); 
    } 
} 

