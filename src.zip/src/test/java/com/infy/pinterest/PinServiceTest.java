package com.infy.pinterest;

import com.infy.pinterest.dto.PinCreationDTO;
import com.infy.pinterest.dto.PinDraftDTO;
import com.infy.pinterest.dto.PinResponseDTO;
import com.infy.pinterest.entity.Board;
import com.infy.pinterest.entity.Pin;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.exception.PinNotFoundException;
import com.infy.pinterest.repository.BoardRepository;
import com.infy.pinterest.repository.PinRepository;
import com.infy.pinterest.repository.UserRepository;
import com.infy.pinterest.service.PinService;
import com.infy.pinterest.utility.FileUploadService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PinServiceTest {

    @Mock
    private PinRepository pinRepository;

    @Mock
    private BoardRepository boardRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private FileUploadService fileUploadService;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private MultipartFile image;

    @InjectMocks
    private PinService pinService;

    private User user;
    private Board board;
    private Pin pin;
    private PinCreationDTO creationDTO;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId("user-123");user.setUsername("johndoe");

        board = new Board();
        board.setBoardId("board-123");
        board.setUserId("user-123");
        board.setName("Travel");

        pin = new Pin();
        pin.setPinId("pin-123");
        pin.setUserId("user-123");
        pin.setBoardId("board-123");
        pin.setTitle("Beautiful Sunset");
        pin.setImageUrl("/uploads/image.jpg");
        pin.setVisibility(Pin.Visibility.PUBLIC);
        pin.setIsDraft(false);

        creationDTO = new PinCreationDTO();
        creationDTO.setTitle("Beautiful Sunset");
        creationDTO.setDescription("Amazing view");
        creationDTO.setBoardId("board-123");
        creationDTO.setVisibility("PUBLIC");
    }

    @Test
    void testCreatePin_Success() {
        // Arrange
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        when(boardRepository.findById(anyString())).thenReturn(Optional.of(board));

        when(fileUploadService.uploadImage(any(MultipartFile.class))).thenReturn("/uploads/image.jpg");
        when(pinRepository.save(any(Pin.class))).thenReturn(pin);

        // Act
        PinResponseDTO result = pinService.createPin("user-123", creationDTO, image);

        // Assert
        assertNotNull(result);
        verify(pinRepository, times(1)).save(any(Pin.class));
    }

    @Test
    void testCreatePinDraft_Success() {
        // Arrange
        PinDraftDTO draftDTO = new PinDraftDTO();
        draftDTO.setTitle("Draft Pin");
        draftDTO.setBoardId("board-123");

        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        when(boardRepository.findById(anyString())).thenReturn(Optional.of(board));
        when(pinRepository.save(any(Pin.class))).thenReturn(pin);
// Act
        PinResponseDTO result = pinService.createPinDraft("user-123", draftDTO);

        // Assert
        assertNotNull(result);
        verify(pinRepository, times(1)).save(any(Pin.class));
    }

    @Test
    void testDeletePin_Success() {
        // Arrange
        when(pinRepository.findByPinIdAndUserId(anyString(),
                anyString())).thenReturn(Optional.of(pin));
        doNothing().when(pinRepository).delete(any(Pin.class));

        // Act
        pinService.deletePin("user-123", "pin-123");

        // Assert
        verify(pinRepository, times(1)).delete(any(Pin.class));
    }

    @Test
    void testGetPinById_Success() {
        // Arrange
        when(pinRepository.findById(anyString())).thenReturn(Optional.of(pin));
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        when(boardRepository.findById(anyString())).thenReturn(Optional.of(board));

        // Act
        PinResponseDTO result = pinService.getPinById("pin-123");

        // Assert
        assertNotNull(result);
    }

    @Test
    void testGetPinById_NotFound() {
        // Arrange
        when(pinRepository.findById(anyString())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(PinNotFoundException.class, () -> {
            pinService.getPinById("invalid-pin");
        });
    }

}
