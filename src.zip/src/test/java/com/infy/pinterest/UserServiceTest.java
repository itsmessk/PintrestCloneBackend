﻿package com.infy.pinterest;

import com.infy.pinterest.dto.*;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.entity.Pin;
import com.infy.pinterest.exception.*;
import com.infy.pinterest.repository.*;
import com.infy.pinterest.service.UserService;
import com.infy.pinterest.utility.FileUploadService;
import com.infy.pinterest.utility.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PinRepository pinRepository;

    @Mock
    private BoardRepository boardRepository;

    @Mock
    private FollowRepository followRepository;

    @Mock
    private BlockedUserRepository blockedUserRepository;

    @Mock
    private FileUploadService fileUploadService;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private UserService userService;

    private User user;
    private Pin pin;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId("user123");
        user.setUsername("testuser");
        user.setEmail("test@example.com");
        user.setPassword("hashedPassword");
        user.setFullName("Test User");
        user.setBio("Test bio");
        user.setMobileNumber("1234567890");
        user.setProfilePictureUrl("https://image.com/profile.jpg");
        user.setAccountType(User.AccountType.personal);
        user.setIsActive(true);
        user.setIsEmailVerified(true);
        user.setDateJoined(LocalDateTime.now());

        pin = new Pin();
        pin.setPinId("pin123");
        pin.setUserId("user123");
        pin.setLikeCount(10);
        pin.setSaveCount(5);
    }

    @Test
    void testGetUserProfile_Success() {
        when(userRepository.findById("user123")).thenReturn(Optional.of(user));
        when(pinRepository.countByUserId("user123")).thenReturn(15);
        when(boardRepository.countByUserId("user123")).thenReturn(5);
        when(followRepository.countByFollowingId("user123")).thenReturn(100L);
        when(followRepository.countByFollowerId("user123")).thenReturn(50L);
        when(pinRepository.findByUserId("user123")).thenReturn(Arrays.asList(pin));

        UserProfileDTO result = userService.getUserProfile("user123", null);

        assertNotNull(result);
        assertEquals("user123", result.getUserId());
        assertEquals("testuser", result.getUsername());
        assertNotNull(result.getStats());
        assertEquals(15, result.getStats().getTotalPins());
        assertEquals(5, result.getStats().getTotalBoards());
    }

    @Test
    void testGetUserProfile_WithViewerRelationship() {
        when(userRepository.findById("user123")).thenReturn(Optional.of(user));
        when(pinRepository.countByUserId("user123")).thenReturn(15);
        when(boardRepository.countByUserId("user123")).thenReturn(5);
        when(followRepository.countByFollowingId("user123")).thenReturn(100L);
        when(followRepository.countByFollowerId("user123")).thenReturn(50L);
        when(pinRepository.findByUserId("user123")).thenReturn(List.of());
        when(followRepository.existsByFollowerIdAndFollowingId("viewer123", "user123")).thenReturn(true);
        when(followRepository.existsByFollowerIdAndFollowingId("user123", "viewer123")).thenReturn(false);
        when(blockedUserRepository.existsByBlockerIdAndBlockedId("viewer123", "user123")).thenReturn(false);

        UserProfileDTO result = userService.getUserProfile("user123", "viewer123");

        assertNotNull(result);
        assertTrue(result.getIsFollowing());
        assertFalse(result.getIsFollower());
        assertFalse(result.getIsBlocked());
    }

    @Test
    void testGetUserProfile_NotFound() {
        when(userRepository.findById("invalid")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () ->
                userService.getUserProfile("invalid", null));
    }

    @Test
    void testGetProfileStats_Success() {
        when(pinRepository.countByUserId("user123")).thenReturn(20);
        when(boardRepository.countByUserId("user123")).thenReturn(10);
        when(followRepository.countByFollowingId("user123")).thenReturn(150L);
        when(followRepository.countByFollowerId("user123")).thenReturn(75L);
        when(pinRepository.findByUserId("user123")).thenReturn(Arrays.asList(pin));

        ProfileStatsDTO result = userService.getProfileStats("user123");

        assertNotNull(result);
        assertEquals(20, result.getTotalPins());
        assertEquals(10, result.getTotalBoards());
        assertEquals(150L, result.getFollowers());
        assertEquals(75L, result.getFollowing());
        assertEquals(5L, result.getTotalPinSaves());
        assertEquals(10L, result.getTotalPinLikes());
    }

    @Test
    void testUpdateProfile_Success() {
        UserUpdateDTO updateDTO = new UserUpdateDTO();
        updateDTO.setFullName("Updated Name");
        updateDTO.setBio("Updated bio");
        updateDTO.setMobileNumber("9876543210");
        updateDTO.setAccountType("business");

        when(userRepository.findById("user123")).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        UserResponseDTO result = userService.updateProfile("user123", updateDTO);

        assertNotNull(result);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testUpdateProfile_NotFound() {
        UserUpdateDTO updateDTO = new UserUpdateDTO();
        when(userRepository.findById("invalid")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () ->
                userService.updateProfile("invalid", updateDTO));
    }

    @Test
    void testUploadProfilePicture_Success() {
        MultipartFile file = mock(MultipartFile.class);
        when(userRepository.findById("user123")).thenReturn(Optional.of(user));
        when(fileUploadService.uploadImage(file)).thenReturn("https://image.com/new-profile.jpg");
        when(userRepository.save(any(User.class))).thenReturn(user);

        UserResponseDTO result = userService.uploadProfilePicture("user123", file);

        assertNotNull(result);
        verify(fileUploadService).uploadImage(file);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testDeleteProfilePicture_Success() {
        when(userRepository.findById("user123")).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        UserResponseDTO result = userService.deleteProfilePicture("user123");

        assertNotNull(result);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testDeactivateAccount_Success() {
        when(userRepository.findById("user123")).thenReturn(Optional.of(user));

        assertDoesNotThrow(() -> userService.deactivateAccount("user123"));
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testReactivateAccount_Success() {
        user.setIsActive(false);
        when(userRepository.findById("user123")).thenReturn(Optional.of(user));

        assertDoesNotThrow(() -> userService.reactivateAccount("user123"));
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testSearchUsers_Success() {
        Pageable pageable = PageRequest.of(0, 20);
        Page<User> userPage = new PageImpl<>(Arrays.asList(user));

        when(userRepository.searchUsers("test", pageable)).thenReturn(userPage);

        PaginatedResponse<UserResponseDTO> result = userService.searchUsers("test", 0, 20);

        assertNotNull(result);
        assertEquals(1, result.getData().size());
        assertEquals(1, result.getPagination().getTotalItems());
    }

    @Test
    void testRegisterUser_Success() {
        UserRegistrationDTO registrationDTO = new UserRegistrationDTO();
        registrationDTO.setUsername("newuser");
        registrationDTO.setEmail("new@example.com");
        registrationDTO.setPassword("Password123!");
        registrationDTO.setConfirmPassword("Password123!");
        registrationDTO.setFullName("New User");
        registrationDTO.setDateOfBirth(LocalDate.of(1990, 1, 1));
        registrationDTO.setAccountType("personal");

        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);
        when(userRepository.existsByUsername("newuser")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(user);

        UserResponseDTO result = userService.registerUser(registrationDTO);

        assertNotNull(result);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testRegisterUser_PasswordMismatch() {
        UserRegistrationDTO registrationDTO = new UserRegistrationDTO();
        registrationDTO.setPassword("Password123!");
        registrationDTO.setConfirmPassword("DifferentPassword!");

        assertThrows(PasswordMismatchException.class, () ->
                userService.registerUser(registrationDTO));
    }

    @Test
    void testRegisterUser_EmailExists() {
        UserRegistrationDTO registrationDTO = new UserRegistrationDTO();
        registrationDTO.setEmail("existing@example.com");
        registrationDTO.setPassword("Password123!");
        registrationDTO.setConfirmPassword("Password123!");

        when(userRepository.existsByEmail("existing@example.com")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () ->
                userService.registerUser(registrationDTO));
    }

    @Test
    void testRegisterUser_UsernameExists() {
        UserRegistrationDTO registrationDTO = new UserRegistrationDTO();
        registrationDTO.setEmail("new@example.com");
        registrationDTO.setUsername("existinguser");
        registrationDTO.setPassword("Password123!");
        registrationDTO.setConfirmPassword("Password123!");

        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);
        when(userRepository.existsByUsername("existinguser")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () ->
                userService.registerUser(registrationDTO));
    }
}
