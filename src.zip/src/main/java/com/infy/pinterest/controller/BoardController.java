package com.infy.pinterest.controller;

import com.infy.pinterest.dto.*;
import com.infy.pinterest.entity.Board;
import com.infy.pinterest.entity.Pin;
import com.infy.pinterest.entity.User;
import com.infy.pinterest.exception.BoardNotFoundException;
import com.infy.pinterest.exception.PinNotFoundException;
import com.infy.pinterest.exception.ResourceNotFoundException;
import com.infy.pinterest.exception.UnauthorizedAccessException;
import com.infy.pinterest.repository.BoardRepository;
import com.infy.pinterest.repository.PinRepository;
import com.infy.pinterest.repository.UserRepository;
import com.infy.pinterest.service.BoardService;
import com.infy.pinterest.utility.FileUploadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/boards")
@Tag(name = "Boards", description = "Board management APIs")
@SecurityRequirement(name = "JWT")
@Slf4j
public class BoardController {
    @Autowired
    private BoardService boardService;

    @PostMapping
    @Operation(summary = "Create a new board")
    public ResponseEntity<ApiResponse<BoardResponseDTO>> createBoard(
            @RequestHeader("X-User-Id") String userId,
            @Valid @RequestBody BoardCreationDTO boardDTO) {
        log.info("POST /boards - Creating board for user: {}", userId);

        BoardResponseDTO response = boardService.createBoard(userId, boardDTO);
        return ResponseEntity
                .status(HttpStatus
                        .CREATED)
                .body(ApiResponse.success("Board created successfully", response));
    }

    @PutMapping("/{boardId}")
    @Operation(summary = "Update a board")
    public ResponseEntity<ApiResponse<BoardResponseDTO>> updateBoard(
            @RequestHeader("X-User-Id") String userId,
            @PathVariable String boardId,
            @Valid @RequestBody BoardUpdateDTO updateDTO) {
        log.info("PUT /boards/{} - Updating board", boardId);

        BoardResponseDTO response = boardService.updateBoard(userId, boardId, updateDTO);
        return ResponseEntity
                .ok(ApiResponse.success("Board updated successfully", response));
    }

    @DeleteMapping("/{boardId}")
    @Operation(summary = "Delete a board")
    public ResponseEntity<ApiResponse<Object>> deleteBoard(
            @RequestHeader("X-User-Id") String userId,
            @PathVariable String boardId) {log.info("DELETE /boards/{} - Deleting board", boardId);

        boardService.deleteBoard(userId, boardId);
        return ResponseEntity
                .ok(ApiResponse.success("Board deleted successfully", null));
    }

    @GetMapping("/{boardId}")
    @Operation(summary = "Get board by ID")
    public ResponseEntity<ApiResponse<BoardResponseDTO>> getBoardById(
            @PathVariable String boardId) {
        log.info("GET /boards/{} - Fetching board details", boardId);

        BoardResponseDTO response = boardService.getBoardById(boardId);
        return ResponseEntity
                .ok(ApiResponse.success("Board retrieved successfully", response));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get user's boards")
    public ResponseEntity<ApiResponse<PaginatedResponse<BoardResponseDTO>>> getUserBoards(
            @PathVariable String userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String sort) {
        log.info("GET /boards/user/{} - Fetching user boards", userId);

        PaginatedResponse<BoardResponseDTO> response = boardService.getUserBoards(userId, page,
                size, sort);
        return ResponseEntity
                .ok(ApiResponse.success("Boards retrieved successfully", response));
    }

    @GetMapping
    @Operation(summary = "Get all public boards for home page")
    public ResponseEntity<ApiResponse<PaginatedResponse<BoardResponseDTO>>> getAllPublicBoards(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @RequestParam(required = false) String sort) {
        log.info("GET /boards - Fetching all public boards");

        PaginatedResponse<BoardResponseDTO> response = boardService.getAllPublicBoards(page, size, sort);
        return ResponseEntity
                .ok(ApiResponse.success("Public boards retrieved successfully", response));
    }

    @GetMapping("/collaborative")
    @Operation(summary = "Get boards where user is a collaborator")
    public ResponseEntity<ApiResponse<PaginatedResponse<BoardResponseDTO>>> getCollaborativeBoards(
            @RequestHeader("X-User-Id") String userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String sort) {
        log.info("GET /boards/collaborative - Fetching collaborative boards for user: {}", userId);

        PaginatedResponse<BoardResponseDTO> response = boardService.getCollaborativeBoards(userId, page, size, sort);
        return ResponseEntity
                .ok(ApiResponse.success("Collaborative boards retrieved successfully", response));
    }

}