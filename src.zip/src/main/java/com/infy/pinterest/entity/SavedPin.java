package com.infy.pinterest.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDateTime;

@Entity
@Table(name = "saved_pins")
@Data
public class SavedPin {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "save_id")
    private String saveId;

    @Column(name = "pin_id", nullable = false)
    private String pinId; // Original pin ID

    @Column(name = "copied_pin_id")
    private String copiedPinId; // The new pin created in user's board

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "board_id")
    private String boardId;

    @Column(name = "saved_at", nullable = false)
    private LocalDateTime savedAt;

    @PrePersist
    protected void onCreate() {
        savedAt = LocalDateTime.now();
    }
}
