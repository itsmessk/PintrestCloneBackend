package com.infy.pinterest.exception;

public class NotFollowingException extends RuntimeException {
    public NotFollowingException(String message) {
        super(message);
    }
}
