package com.infy.pinterest.exception;

public class FileUploadException extends RuntimeException {
    public FileUploadException(String message) {

        super(message);
    }
}
