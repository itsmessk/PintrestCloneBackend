package com.infy.pinterest.exception;

public class InvalidInvitationStatusException extends RuntimeException {
    public InvalidInvitationStatusException(String message) {
        super(message);
    }
}
